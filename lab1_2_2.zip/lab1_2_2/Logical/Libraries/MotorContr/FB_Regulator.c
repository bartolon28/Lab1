
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "MotorContr.h"
#ifdef __cplusplus
	};
#endif
/* TODO: Add your comment here */
void FB_Regulator(struct FB_Regulator* inst)
{
	REAL u_p = inst->e * inst->k_p;
	if (u_p > inst->max_abs_value) u_p = inst->max_abs_value;
	else if (u_p < -inst->max_abs_value) u_p = -inst->max_abs_value;
	REAL u_i = inst->integrator.out;
	REAL u_pre = u_p + u_i;
	
	inst->u = u_pre;
	if (inst->u > inst->max_abs_value) inst->u = inst->max_abs_value;
	else if (inst->u < -inst->max_abs_value) inst->u = -inst->max_abs_value;
	
	inst->integrator.dt = inst->dt;
	inst->integrator.in = (inst->e * inst->k_i) - (u_pre - inst->u);
	FB_Integrator(&inst->integrator);
	
	/*TODO: Add your code here*/
}
