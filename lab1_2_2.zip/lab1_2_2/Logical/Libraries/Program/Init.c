
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif
#define DT  0.01
#define T_j  0.02
#define T_m  0.1
#define K_e  0.048
#define UMAX  24

void _INIT ProgramInit(void)
{	
	fb_motor.Tm = T_m;
	fb_motor.ke = K_e;
	fb_motor.dt = DT;
	fb_motor.integrator.dt = DT;
	fb_motor.w = 0;
	fb_motor.phi = 0;
	
	fb_motor_2.Tm = T_m;
	fb_motor_2.ke = K_e;
	fb_motor_2.dt = DT;
	fb_motor_2.integrator.dt = DT;
	fb_motor_2.w = 0;
	fb_motor_2.phi = 0;
	
	fb_controller.k_p = K_e*T_m/T_j;
	fb_controller.k_i = K_e/T_j;
	fb_controller.max_abs_value = UMAX;
	fb_controller.dt = DT;
	fb_controller.integrator.dt = DT;
	fb_controller.iyOld = 0;
	
	
	
	Speed = 0;
	Enable = 1;
	counter = 0;
}
