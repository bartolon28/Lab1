
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif
#define STEP  50
#define SPEED_SET  60
void _CYCLIC ProgramCyclic(void)
{
	counter++;
	if (counter < STEP)
		Speed = 0;
	else if (counter < 2 * STEP)
		Speed = SPEED_SET;
	else if (counter < 3 * STEP)
		Speed = 0;
	else
		counter = 0;
	if (Enable)
	{
		fb_controller.e = Speed - fb_motor.w;
		FB_Regulator(&fb_controller);
		fb_motor.u = fb_controller.u;
	}
	else
	{
		fb_controller.e = 0;
		fb_controller.integrator.out = 0;
		fb_controller.u = 0;
		fb_motor.u = 0;
	}
	
		FB_Motor(&fb_motor);
		fb_motor_2.u =Speed * fb_motor_2.ke;
		FB_Motor(&fb_motor_2);
		

}
