/* Automation Studio generated header file */
/* Do not edit ! */
/* MotorContr  */

#ifndef _MOTORCONTR_
#define _MOTORCONTR_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Datatypes and datatypes of function blocks */
typedef struct FB_Integrator
{
	/* VAR_INPUT (analog) */
	float in;
	float in2;
	/* VAR_OUTPUT (analog) */
	float out;
	float out2;
	/* VAR (analog) */
	float dt;
	float dt2;
} FB_Integrator_typ;

typedef struct FB_Motor
{
	/* VAR_INPUT (analog) */
	float u;
	float u2;
	/* VAR_OUTPUT (analog) */
	float w;
	float phi;
	float w2;
	float phi2;
	/* VAR (analog) */
	struct FB_Integrator integrator;
	float Tm;
	float ke;
	struct FB_Integrator integrator2;
	float Tm2;
	float ke2;
	float dt;
} FB_Motor_typ;

typedef struct FB_Regulator
{
	/* VAR_INPUT (analog) */
	float e;
	/* VAR_OUTPUT (analog) */
	float u;
	/* VAR (analog) */
	float k_p;
	float k_i;
	struct FB_Integrator integrator;
	float iyOld;
	float max_abs_value;
	float dt;
} FB_Regulator_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void FB_Motor(struct FB_Motor* inst);
_BUR_PUBLIC void FB_Regulator(struct FB_Regulator* inst);
_BUR_PUBLIC void FB_Integrator(struct FB_Integrator* inst);


#ifdef __cplusplus
};
#endif
#endif /* _MOTORCONTR_ */

